import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;


public class Jail {

static final Pattern BAD = Pattern.compile(
"(?i)(" +
"java\\.io|java\\.nio|java\\.net|" +
"ProcessBuilder|Runtime|getRuntime|exec|" +
"File|Files|Path|Paths|" +
"\\bClass\\b|forName|reflect|" +
"System\\.|SecurityManager" +
")"
);


static String readFlag() throws Exception {
try (InputStream is = Jail.class.getResourceAsStream("/flag.txt")) {
if (is == null) return "missing";
return new String(is.readAllBytes(), StandardCharsets.UTF_8).trim();
}
}


public static void main(String[] args) throws Exception {
BufferedReader br = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
String expr = br.readLine();
if (expr == null) expr = "";


if (expr.length() > 200) {
System.out.println("too long");
return;
}
if (BAD.matcher(expr).find()) {
System.out.println("nope");
return;
}


String src =
"public class Main {\n" +
" public static void main(String[] a) throws Exception {\n" +
" Object r = (" + expr + ");\n" +
" System.out.println(String.valueOf(r));\n" +
" }\n" +
"}\n";


Path dir = Files.createTempDirectory("jail");
Files.write(dir.resolve("Main.java"), src.getBytes(StandardCharsets.UTF_8));


// Compile (timeout)
Process p1 = new ProcessBuilder("javac", "Main.java")
.directory(dir.toFile())
.redirectErrorStream(true)
.start();


if (!p1.waitFor(6, TimeUnit.SECONDS)) {
p1.destroyForcibly();
System.out.println("compile timeout");
return;
}
if (p1.exitValue() != 0) {
System.out.println("compile error");
return;
}


// Run (timeout)
Process p2 = new ProcessBuilder("java", "-Djava.io.tmpdir=/tmp", "Main")
.directory(dir.toFile())
.redirectErrorStream(true)
.start();


if (!p2.waitFor(1, TimeUnit.SECONDS)) {
p2.destroyForcibly();
System.out.println("run timeout");
return;
}


String out2 = new String(p2.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
System.out.print(out2);
}
}
