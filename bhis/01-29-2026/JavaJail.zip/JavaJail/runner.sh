#!/usr/bin/env bash
set -euo pipefail

TOTAL_TIMEOUT="${TOTAL_TIMEOUT:-8}"

echo "JavaJail: enter an expression per line. Ctrl-D to quit."
echo -n "> "

while IFS= read -r PAYLOAD; do
  set +e
  OUT="$(printf '%s\n' "$PAYLOAD" | timeout "$TOTAL_TIMEOUT" java -cp /app Jail 2>&1)"
  RC=$?
  set -e

  if [ "$RC" -eq 124 ]; then
    echo "timeout"
  else
    printf '%s\n' "$OUT"
  fi

  echo -n "> "
done
