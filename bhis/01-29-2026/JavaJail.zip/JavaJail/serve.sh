#!/usr/bin/env bash
set -euo pipefail

exec docker run --rm -i \
  --network=none \
  --read-only \
  --pids-limit=64 \
  --memory=256m \
  --cpus=0.5 \
  --tmpfs /tmp:rw,nosuid,nodev,exec,size=64m \
  -e TOTAL_TIMEOUT=8 \
  java-jail
