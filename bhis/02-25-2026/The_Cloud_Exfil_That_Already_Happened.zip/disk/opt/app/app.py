import os, json, requests

SENDGRID_ENDPOINT = os.getenv("SENDGRID_ENDPOINT", "https://api.sendgrid.com/v3/mail/send")
API_KEY = os.getenv("SENDGRID_API_KEY")

def send_report(to_email: str, subject: str, content: str):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "personalizations": [{"to": [{"email": to_email}]}],
        "from": {"email": "noreply@corp.local"},
        "subject": subject,
        "content": [{"type": "text/plain", "value": content}],
    }
    r = requests.post(SENDGRID_ENDPOINT, headers=headers, data=json.dumps(payload))
    return r.status_code, r.text

if __name__ == "__main__":
    # normal daily ops for SlidesMover
    print(send_report(os.getenv("REPORT_TO","finance@corp.local"), "Daily report", "OK"))
