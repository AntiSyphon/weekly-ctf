(async function () {
  const invoiceId = window.__INVOICE_ID__;
  if (!invoiceId) return;

  const box = document.getElementById("invoiceBox");
  const downloadLink = document.getElementById("downloadLink");

  try {
    const res = await fetch(`/api/invoices?invoice_id=${encodeURIComponent(invoiceId)}`, {
      headers: { "Accept": "application/json" }
    });

    if (!res.ok) {
      box.classList.remove("skeleton");
      box.innerHTML = `<div class="alert">Failed to load invoice (${res.status}).</div>`;
      return;
    }

    const data = await res.json();
    const inv = data.invoice;

    const amount = (inv.amount_cents / 100).toFixed(2);

    box.classList.remove("skeleton");
    box.innerHTML = `
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;">
        <div>
          <div class="muted">Company</div>
          <div style="font-size:20px;font-weight:800;margin-top:2px;">${escapeHtml(inv.company_name)}</div>
          <div class="muted" style="margin-top:6px;">Invoice <b>${escapeHtml(inv.invoice_no)}</b> • <span class="badge badge-${(inv.status||"").toLowerCase()}">${escapeHtml(inv.status)}</span></div>
        </div>
        <div class="right">
          <div class="muted">Amount</div>
          <div style="font-size:20px;font-weight:900;margin-top:2px;">${amount} ${escapeHtml(inv.currency)}</div>
          <div class="muted" style="margin-top:6px;">Issue: ${escapeHtml(inv.issue_date)}<br/>Due: ${escapeHtml(inv.due_date)}</div>
        </div>
      </div>

      <div class="kv">
        <div class="item">
          <div class="k">Bill To</div>
          <div class="v">${inv.bill_to}</div>
        </div>
        <div class="item">
          <div class="k">Invoice ID</div>
          <div class="v mono">${inv.id}</div>
        </div>
      </div>

      <div style="margin-top:12px;">
        <div class="muted">Description</div>
        <div style="margin-top:4px;font-weight:700;">${escapeHtml(inv.description)}</div>
      </div>

      <div style="margin-top:12px;">
        <div class="muted">Notes</div>
        <div class="mono" style="margin-top:6px;padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.03)">
          ${escapeHtml(inv.notes || "-")}
        </div>
      </div>
    `;

    if (downloadLink) downloadLink.href = `/api/invoices/download?id=${encodeURIComponent(inv.id)}`;
  } catch (e) {
    box.classList.remove("skeleton");
    box.innerHTML = `<div class="alert">Error loading invoice.</div>`;
  }

  function escapeHtml(s) {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }
})();
