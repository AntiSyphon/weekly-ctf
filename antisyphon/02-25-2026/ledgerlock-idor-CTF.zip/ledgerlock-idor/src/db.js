const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3");

const DB_PATH = process.env.DB_PATH || path.join(__dirname, "..", "data", "app.db");
let db;

function initDb() {
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

  const firstRun = !fs.existsSync(DB_PATH);
  db = new Database(DB_PATH);

  db.pragma("journal_mode = WAL");

  if (firstRun) {
    const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf-8");
    db.exec(schema);

    const seed = fs.readFileSync(path.join(__dirname, "seed.sql"), "utf-8");
    db.exec(seed);

    console.log("Database initialized + seeded.");
  }
}

module.exports = {
  initDb,
  get db() { return db; }
};
