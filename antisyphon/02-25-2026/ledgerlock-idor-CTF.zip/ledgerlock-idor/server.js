const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const csrf = require("csurf");

const dbMod = require("./src/db");
const { initDb } = dbMod;

const app = express();
const PORT = process.env.PORT || 3000;

initDb();
const db = dbMod.db;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(helmet({
  contentSecurityPolicy: false // keep CSP off for simplicity in a CTF
}));
app.use(morgan("combined"));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser(process.env.COOKIE_SECRET || "dev_cookie_secret"));

app.use("/static", express.static(path.join(__dirname, "public")));

const csrfProtection = csrf({ cookie: { httpOnly: true, sameSite: "lax" } });

const apiLimiter = rateLimit({
  windowMs: 10 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false
});

// --- helpers ---
function requireAuth(req, res, next) {
  if (!req.signedCookies || !req.signedCookies.session) return res.redirect("/login");
  try {
    const session = JSON.parse(req.signedCookies.session);
    if (!session || !session.userId) return res.redirect("/login");
    req.session = session;
    return next();
  } catch (e) {
    return res.redirect("/login");
  }
}

function apiRequireAuth(req, res, next) {
  if (!req.signedCookies || !req.signedCookies.session) return res.status(401).json({ error: "Unauthorized" });
  try {
    const session = JSON.parse(req.signedCookies.session);
    if (!session || !session.userId) return res.status(401).json({ error: "Unauthorized" });
    req.session = session;
    return next();
  } catch (e) {
    return res.status(401).json({ error: "Unauthorized" });
  }
}

function setSession(res, sessionObj) {
  res.cookie("session", JSON.stringify(sessionObj), {
    signed: true,
    httpOnly: true,
    sameSite: "lax"
  });
}

// --- routes ---
app.get("/", (req, res) => res.redirect("/dashboard"));

app.get("/login", csrfProtection, (req, res) => {
  res.render("login", {
    csrfToken: req.csrfToken(),
    error: null
  });
});

app.get("/register", csrfProtection, (req, res) => {
  const companies = db.prepare("SELECT id, name FROM companies ORDER BY name").all();
  res.render("register", {
    csrfToken: req.csrfToken(),
    error: null,
    companies
  });
});

app.post("/register", csrfProtection, (req, res) => {
  const { full_name, email, password, company_id } = req.body;

  const companies = db.prepare("SELECT id, name FROM companies ORDER BY name").all();

  if (!full_name || !email || !password) {
    return res.status(400).render("register", { csrfToken: req.csrfToken(), error: "All fields are required.", companies });
  }

  const cid = Number(company_id);
  if (!Number.isFinite(cid)) {
    return res.status(400).render("register", { csrfToken: req.csrfToken(), error: "Choose a company.", companies });
  }

  const company = db.prepare("SELECT id FROM companies WHERE id=?").get(cid);
  if (!company) {
    return res.status(400).render("register", { csrfToken: req.csrfToken(), error: "Invalid company.", companies });
  }

  try {
    const info = db.prepare("INSERT INTO users(email, password, full_name, role, company_id) VALUES (?, ?, ?, 'user', ?)")
      .run(email.trim().toLowerCase(), password, full_name.trim(), cid);

    const user = db.prepare("SELECT id, email, full_name, company_id, role FROM users WHERE id=?").get(info.lastInsertRowid);

    setSession(res, { userId: user.id, email: user.email, name: user.full_name, companyId: user.company_id, role: user.role });
    return res.redirect("/dashboard");
  } catch (e) {
    // likely UNIQUE constraint on email
    return res.status(409).render("register", { csrfToken: req.csrfToken(), error: "Email already registered.", companies });
  }
});

app.post("/login", csrfProtection, (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT id, email, full_name, company_id, role FROM users WHERE email=? AND password=?")
    .get(email, password);

  if (!user) {
    return res.status(401).render("login", { csrfToken: req.csrfToken(), error: "Invalid credentials." });
  }

  setSession(res, { userId: user.id, email: user.email, name: user.full_name, companyId: user.company_id, role: user.role });
  return res.redirect("/dashboard");
});

app.post("/logout", csrfProtection, (req, res) => {
  res.clearCookie("session");
  res.clearCookie("_csrf");
  return res.redirect("/login");
});

app.get("/dashboard", requireAuth, csrfProtection, (req, res) => {
  const user = db.prepare("SELECT id, email, full_name, company_id FROM users WHERE id=?").get(req.session.userId);
  if (!user) {
    res.clearCookie("session");
    res.clearCookie("_csrf");
    return res.redirect("/login");
  }
  const company = db.prepare("SELECT id, name, logo FROM companies WHERE id=?").get(user.company_id);

  // show only YOUR invoices in the UI (this part is correct)
  const invoices = db.prepare("SELECT id, invoice_no, amount_cents, currency, status, issue_date FROM invoices WHERE company_id=? ORDER BY id DESC LIMIT 12")
    .all(company.id);

  res.render("dashboard", {
    csrfToken: req.csrfToken(),
    user,
    company,
    invoices
  });
});

app.get("/invoice/:id", requireAuth, csrfProtection, (req, res) => {
  // The page loads invoice details via API call (vulnerable endpoint)
  const user = db.prepare("SELECT id, company_id FROM users WHERE id=?").get(req.session.userId);
  if (!user) {
    res.clearCookie("session");
    res.clearCookie("_csrf");
    return res.redirect("/login");
  }
  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).send("Bad request");

  res.render("invoice", {
    csrfToken: req.csrfToken(),
    invoiceId: id
  });
});

// --- VULNERABLE API ---
// Broken Access Control / IDOR: authenticated users can fetch invoices belonging to other companies
app.get("/api/invoices", apiLimiter, apiRequireAuth, (req, res) => {
  const invoiceId = Number(req.query.invoice_id);
  if (!Number.isFinite(invoiceId)) return res.status(400).json({ error: "Bad invoice_id" });

  const row = db.prepare(`
    SELECT i.id, i.invoice_no, i.company_id, c.name as company_name,
           i.amount_cents, i.currency, i.status, i.issue_date, i.due_date,
           i.description, i.notes, i.bill_to, i.created_at
    FROM invoices i
    JOIN companies c ON c.id = i.company_id
    WHERE i.id = ?
  `).get(invoiceId);

  if (!row) return res.status(404).json({ error: "Not found" });

  // ❌ Missing authorization check:
  // expected:
  // if (row.company_id !== req.session.companyId) return res.status(403).json({ error: "Forbidden" });

  return res.json({ invoice: row });
});

// Optional: a "download PDF" endpoint (still vulnerable)
app.get("/api/invoices/download", apiLimiter, apiRequireAuth, (req, res) => {
  const invoiceId = Number(req.query.id);
  if (!Number.isFinite(invoiceId)) return res.status(400).send("Bad id");

  const row = db.prepare(`
    SELECT i.id, i.invoice_no, i.company_id, c.name as company_name,
           i.amount_cents, i.currency, i.status, i.issue_date, i.due_date,
           i.description, i.notes, i.bill_to
    FROM invoices i
    JOIN companies c ON c.id = i.company_id
    WHERE i.id = ?
  `).get(invoiceId);

  if (!row) return res.status(404).send("Not found");

  const amount = (row.amount_cents / 100).toFixed(2);

  // Simple HTML "download" to keep deps minimal
  const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>Invoice ${row.invoice_no}</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu; padding:24px; color:#111;}
  .card{border:1px solid #ddd;border-radius:12px;padding:18px;max-width:820px;margin:0 auto;}
  .top{display:flex;justify-content:space-between;gap:16px;align-items:flex-start;}
  h1{margin:0;font-size:22px;}
  .muted{color:#666;font-size:12px;}
  table{width:100%;border-collapse:collapse;margin-top:14px;}
  td{padding:10px;border-top:1px solid #eee;vertical-align:top;}
  .right{text-align:right;}
  .notes{margin-top:14px;padding:12px;background:#f7f7f7;border-radius:10px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;}
</style></head>
<body>
  <div class="card">
    <div class="top">
      <div>
        <h1>${row.company_name}</h1>
        <div class="muted">Invoice <b>${row.invoice_no}</b> • Status: ${row.status}</div>
      </div>
      <div class="muted right">
        Issue: ${row.issue_date}<br>
        Due: ${row.due_date}
      </div>
    </div>

    <table>
      <tr><td><b>Bill To</b><br>${row.bill_to}</td><td class="right"><b>Amount</b><br>${amount} ${row.currency}</td></tr>
      <tr><td colspan="2"><b>Description</b><br>${row.description}</td></tr>
    </table>

    <div class="notes"><b>Notes</b><br>${row.notes || "-"}</div>
  </div>
</body></html>`;

  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="invoice-${row.invoice_no}.html"`);
  return res.send(html);
});

app.get("/health", (req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`LedgerLock CTF listening on port ${PORT}`);
});
